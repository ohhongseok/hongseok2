package com.example.hongseokapp;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends Activity{
    EditText tbox1;
    Button btn1, btn2;
    RadioGroup Rgroup;
    RadioButton r1, r2;
    ImageView img1;
    Intent tent1;

        @Override
        protected void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            setTitle("android app");

            tbox1 =findViewById(R.id.tbox1);
            btn1 =findViewById(R.id.btn1);
            btn2 =findViewById(R.id.btn2);
            Rgroup=findViewById(R.id.rgroup);
            r1=findViewById(R.id.r1);
            r2=findViewById(R.id.r2);
            img1=findViewById(R.id.img1);

            btn1.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    Toast.makeText(getApplicationContext(),
                            tbox1.getText().toString(),Toast.LENGTH_LONG).show();
                }
            });
            btn2.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    tent1=new Intent(Intent.ACTION_VIEW,
                            Uri.parse(tbox1.getText().toString()));
                    startActivity(tent1);
                }
            });

            r1.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    img1.setImageResource(R.drawable.pie);
                }
            });
            r2.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    img1.setImageResource(R.drawable.oreo);
                }
            });
        }
}