 var modal = document.getElementById('myModal'); //모달 객체 생성
 var btn = document.getElementById("myBtn"); //모달을 열기위한 btn 객체 생성
 var span = document.getElementsByClassName("close")[0]; //x버튼 span 요소로 생성                      
 //모달창 여는 기능 수행(onclick 수행 시)
 btn.onclick = function() {
     modal.style.display = "block";
 }
 //x 클릭시 누를시 모달창 사라짐
 span.onclick = function() {
     modal.style.display = "none";
 }
 //모달창 부분을 제외한 윈도우 전체의 부분을 눌러도 창이 사라지게 구성
 window.onclick = function(event) {
     if (event.target == modal) {
         modal.style.display = "none";
     }
 }
 //부트스트랩 참고

 