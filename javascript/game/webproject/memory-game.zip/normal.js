/*사용할 카드요소 말들기*/
const cards = document.querySelectorAll('.memory-card');

let PairCheck = false;
var cardCount=6;  //카드 카운팅할 변수
//오류case 제가히기 위한 코드, 서로다른카드 3장 누를시
let lockCard = false;
//비교할 카드,첫번째카드 두번째카드 인식할얘
let firstCard, secondCard;

function flipCard() {
  //오류발생 방지를 위한 lockCard 연속으로 세장 이상 빠르게 누를때 방지
  if (lockCard) return;
  //오류, 첫번째카드 더블클릭시 두번째카드 누르면
  //두번째카드 매치여부에 상관없이 카드가 뒤집어짐
  if (this === firstCard) return;
  this.classList.add('flip');
  //첫번째 카드 누르기
  if (!PairCheck) {
  //  PairCheck = true;
    firstCard = this;

    return;
  }
  //두번째 카드 누르기
  secondCard = this;
  checkForMatch();
}

function checkForMatch() {
  let isMatch = firstCard.dataset.framework === secondCard.dataset.framework;
  //만약 카드가 맞다면 disableCards()를 호출해 이벤트 리스너 삭제
  isMatch ? disableCards() : unflipCards();
}
//첫번째와 두번째 카드를 매치했을때 동일한 카드이면 removeEventListner 실행
function disableCards() {
  firstCard.removeEventListener('click', flipCard);
  secondCard.removeEventListener('click', flipCard);
  cardCount--;

  if(cardCount===0)
  {
    setTimeout(() => {
      alert("끄읏!~");
    },1000);
  }
  initialize();
}
//동일하지 않은 카드일때 다시 카드를 뒤집기
function unflipCards() {
  lockCard = true;
  setTimeout(() => {
    firstCard.classList.remove('flip');
    secondCard.classList.remove('flip');

    initialize();
    //딜레이를 주어 자연스러운 게임 흐름을 줌
  }, 1500);
}

function initialize() {
  [PairCheck, lockCard] = [false, false];
  [firstCard, secondCard] = [null, null];
}

(function shuffle() {
  cards.forEach(card => {
    let randomPos = Math.floor(Math.random() * 12);
    card.style.order = randomPos;
  });
})();
/*모든 카드에 대해 뒤집기 시행*/
cards.forEach(card => card.addEventListener('click', flipCard));