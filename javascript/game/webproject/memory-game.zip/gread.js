const cards = document.querySelectorAll('.memory-card');

let PairCheck = false;
var cardCount=6;  //카드 카운팅할 변수
var checkFlipNum=0; //카드 뒤집는 쌍을 카운트할 변수
var checkFlipNumforCounting=1; //뒤집은 쌍 횟수 카운트
//카드 두개만 비교할 제어기
let lockCard = false;
let firstCard, secondCard;

function flipCard() {
  checkGread();
  counting();
  if (lockCard) return;
  if (this === firstCard) return;

  this.classList.add('flip');
  //첫번째 카드 누르기
  if (!PairCheck) {
    PairCheck = true;
    firstCard = this;

    return;
  }
  //두번째 카드 누르기
  secondCard = this;
  //별 갯수 들어갈 부분
  checkForMatch();
}

function checkForMatch() {
  let isMatch = firstCard.dataset.framework === secondCard.dataset.framework;
  //만약 카드가 맞다면 disableCards()를 호출해 이벤트 리스너 삭제
  isMatch ? disableCards() : unflipCards();
}
//첫번째와 두번째 카드를 매치했을때 동일한 카드이면 removeEventListner 실행
function disableCards() {
  firstCard.removeEventListener('click', flipCard);
  secondCard.removeEventListener('click', flipCard);
  cardCount--;
  checkFlipNum++;  //등급을 내기 위한 CKFlipNum
  checkFlipNumforCounting++;
  console.log(checkFlipNum);
  if(cardCount===0)
  {
    alert("끄읏!");
  }
  initialize();
}
//동일하지 않은 카드일때 다시 카드를 뒤집기
function unflipCards() {
  lockCard = true;

  setTimeout(() => {
    firstCard.classList.remove('flip');
    secondCard.classList.remove('flip');
    checkFlipNum++;  //등급을 내기 위한 CKFlipNum
    checkFlipNumforCounting++;
    console.log(checkFlipNum);
    initialize();
    //첫번째 카드와 두번째 카드의 뒤집는 시간의
    //딜레이를 주어1500초 카드 뒤집기에 충분한 시간 제공
  }, 1500);
}

function initialize() {
  [PairCheck, lockCard] = [false, false];
  [firstCard, secondCard] = [null, null];
}

(function shuffle() {
  cards.forEach(card => {
    let randomPos = Math.floor(Math.random() * 12);
    card.style.order = randomPos;
  });
})();

cards.forEach(card => card.addEventListener('click', flipCard));

//등급이랑, 뒤집은 횟수 보여주기
function counting()
{
  document.getElementById('count').innerHTML='뒤집은 횟수 : '+ checkFlipNumforCounting;
}
function checkGread()
{
  if(checkFlipNum<=13)
  {
      document.getElementById('gread').innerHTML='★★★';
  }
  if(checkFlipNum>=13&&checkFlipNum<18)
  {
      document.getElementById('gread').innerHTML='★★☆';
  }
  if(checkFlipNum>=18)
  {
    document.getElementById('gread').innerHTML='★☆☆';
  }
}