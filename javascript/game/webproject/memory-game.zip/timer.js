const cards = document.querySelectorAll('.memory-card');

let PairCheck = false;
var cardCount=6;  //카드 카운팅할 변수
var checkFlipNum=0; //시간을 제어하기 ctrl
//카드 두개만 비교할 제어기
let lockCard = false;
let firstCard, secondCard;


function flipCard() {
  if (lockCard) return;
  if (this === firstCard) return;

  this.classList.add('flip');
  //첫번째 카드 누르기
  if (!PairCheck) {
    PairCheck = true;
    firstCard = this;
    //카드의 매칭 여부와 상관없이 카드가 뒤집어지는 순간부터 카운팅
    checkFlipNum++;
    return;
  }
  //두번째 카드 누르기
  secondCard = this;
  checkForMatch();
}

function checkForMatch() {
  let isMatch = firstCard.dataset.framework === secondCard.dataset.framework;
  //만약 카드가 맞다면 disableCards()를 호출해 이벤트 리스너 삭제
  isMatch ? disableCards() : unflipCards();
}
//첫번째와 두번째 카드를 매치했을때 동일한 카드이면 removeEventListner 실행
function disableCards() {
  firstCard.removeEventListener('click', flipCard);
  secondCard.removeEventListener('click', flipCard);
  //횟수 카운트 및 조건
  cardCount--;
  if(cardCount===0)
  {
    setTimeout(() => {
      alert("끄읏!~");
    },1000);
  }
  initialize();
}
//동일하지 않은 카드일때 다시 카드를 뒤집기
function unflipCards() {
  lockCard = true;

  setTimeout(() => {
    firstCard.classList.remove('flip');
    secondCard.classList.remove('flip');

    initialize();
    //첫번째 카드와 두번째 카드의 뒤집는 시간의
    //딜레이를 주어1500초 카드 뒤집기에 충분한 시간 제공
  }, 1500);
}

function initialize() {
  [PairCheck, lockCard] = [false, false];
  [firstCard, secondCard] = [null, null];
}

(function shuffle() {
  cards.forEach(card => {
    let randomPos = Math.floor(Math.random() * 12);
    card.style.order = randomPos;
  });
})();

cards.forEach(card => card.addEventListener('click', flipCard));

var count=30;
var counter=setInterval(timer,1000);
function timer()
{
  if(checkFlipNum!=0)
  {
    console.log(count)
    count--; //60에서 계속 마이너스
    if(count<=0) //30초 경과되면
    {             //작업 끝
      clearInterval(counter);
      alert("실패ㅠㅠ");
    }
    else
    document.getElementById("timer").innerHTML='남은시간 : '+count;
  }
}